# OwlFly

A production-ready, modular, Flappy-style endless flyer built with **vanilla JavaScript + Canvas**.
- Obstacles: **cactus pairs** (not pipes)
- Difficulty scaling
- “Easy confidence” pattern injection (every 12 cactuses, 3 are easier)
- High score persistence
- PWA-ready (`manifest.webmanifest`, `sw.js`)
- Capacitor-friendly (the `web/` folder is the distributable)

## Quick start

```bash
npm install
npm run dev
```

Open:
- http://localhost:5173

## Build (copies src → web/game.js)

Windows PowerShell:
```powershell
npm run build:ps
```

Mac/Linux:
```bash
npm run build
```

## Where things live

- `src/` — source modules
- `web/` — distributable (what Capacitor should wrap)
- `web/game.js` — the built entry (generated)
- `web/index.html` — loads `game.js`

## Controls

- Tap / Space / Click — flap
- Esc — pause/unpause
- Enter — restart (game over)

## Customizing

- Tune gameplay constants in `src/core/constants.js`
- Tune obstacle pacing in `src/systems/spawner.js`
- Tune difficulty curve in `src/engine/difficulty.js`

## License

MIT
