// GENERATED FILE — run tooling/build.ps1 or tooling/build.sh to regenerate.
// This placeholder allows the repo to run even before first build.
import "../src/app/boot.js";
