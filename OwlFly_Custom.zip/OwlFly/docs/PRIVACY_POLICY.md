# Privacy Policy (Template)

OwlFly stores:
- High score
- Basic settings (mute, reduced motion)

All storage is local on your device (localStorage). OwlFly does not collect personal data, does not transmit data to servers, and does not share data with third parties.

If ads or analytics are added in future versions, this policy must be updated accordingly.
