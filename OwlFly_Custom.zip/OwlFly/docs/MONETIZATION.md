# Monetization (safe baseline)

## Recommended
- Rewarded ad to continue after a crash (1 per run)
- Interstitial after game over every N runs
- Cosmetic skins (owl colors, cactus variants, sky themes)
- Remove-ads purchase

## Implementation approach
- Keep ad calls behind a thin interface.
- In web build, provide stub implementations.
- In Capacitor build, replace with platform plugin integration.
