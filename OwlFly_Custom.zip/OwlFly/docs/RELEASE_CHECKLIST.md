# Release Checklist

- [ ] Replace placeholder icons in `web/assets/icons/`
- [ ] Replace placeholder audio in `web/assets/audio/`
- [ ] Confirm gameplay feel (gravity/jump/gap sizes)
- [ ] Confirm “easy-run injection” pacing feels right
- [ ] Verify PWA install + offline works
- [ ] Run Lighthouse check (Performance + PWA)
- [ ] Build Capacitor Android/ iOS (if applicable)
- [ ] Store listing screenshots + description
