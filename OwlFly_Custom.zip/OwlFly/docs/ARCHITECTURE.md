# OwlFly Architecture

## Layers
- **App**: bootstraps and wires systems (`src/app/boot.js`)
- **Core**: constants, RNG, storage
- **Engine**: loop, input, physics, collision, difficulty
- **Entities**: owl + cactus pairs
- **Systems**: spawner + scoring
- **Render**: draws world
- **UI**: DOM overlays (menu, HUD, game over)

## Main data flow
Input → Owl physics → Spawner updates obstacles → Collision checks → Scoring updates → Renderer draws → UI updates

## Performance
- Object pooling for cactus pairs
- Fixed timestep loop
- Minimal allocations per frame
