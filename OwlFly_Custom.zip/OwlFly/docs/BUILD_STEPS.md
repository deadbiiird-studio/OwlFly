# Build steps

## Dev (local)
```bash
npm install
npm run dev
```

## Build bundle
Windows:
```powershell
npm run build:ps
```

Mac/Linux:
```bash
npm run build
```

This regenerates `web/game.js`.
