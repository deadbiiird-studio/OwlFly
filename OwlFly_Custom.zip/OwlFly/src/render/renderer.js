import { GAME, OWL } from "../core/constants.js";

export class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d", { alpha: false });

    this._time = 0;

    this._resize = () => this.resizeToFit();
    window.addEventListener("resize", this._resize);
    this.resizeToFit();
  }

  dispose() {
    window.removeEventListener("resize", this._resize);
  }

  resizeToFit() {
    const dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
    this.canvas.width = Math.floor(GAME.BASE_WIDTH * dpr);
    this.canvas.height = Math.floor(GAME.BASE_HEIGHT * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  render(state) {
    const { owl, spawner, mode, paused } = state;
    this._time += 1 / 60;

    const ctx = this.ctx;

    drawSky(ctx, this._time);
    drawGround(ctx, this._time);

    for (const o of spawner.active) {
      const { top, bottom } = o.getRects();
      drawCactus(ctx, top.x, top.y, top.w, top.h, true);
      drawCactus(ctx, bottom.x, bottom.y, bottom.w, bottom.h, false);
    }

    drawOwl(ctx, owl.x, owl.y, owl.rot, owl.blink);

    if (paused && mode === "playing") {
      ctx.save();
      ctx.fillStyle = "rgba(0,0,0,0.35)";
      ctx.fillRect(0, 0, GAME.BASE_WIDTH, GAME.BASE_HEIGHT);
      ctx.fillStyle = "rgba(255,255,255,0.9)";
      ctx.font = "800 22px system-ui";
      ctx.textAlign = "center";
      ctx.fillText("PAUSED", GAME.BASE_WIDTH / 2, GAME.BASE_HEIGHT * 0.42);
      ctx.font = "600 14px system-ui";
      ctx.fillStyle = "rgba(255,255,255,0.7)";
      ctx.fillText("Press Esc to resume", GAME.BASE_WIDTH / 2, GAME.BASE_HEIGHT * 0.42 + 28);
      ctx.restore();
    }
  }
}

function drawSky(ctx, t) {
  const g = ctx.createLinearGradient(0, 0, 0, GAME.BASE_HEIGHT);
  g.addColorStop(0, "#0b1630");
  g.addColorStop(1, "#1a0f1b");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, GAME.BASE_WIDTH, GAME.BASE_HEIGHT);

  ctx.save();
  ctx.globalAlpha = 0.65;
  for (let i = 0; i < 45; i++) {
    const x = (i * 97 + (t * 22)) % GAME.BASE_WIDTH;
    const y = (i * 53) % 340;
    ctx.fillStyle = `rgba(255,255,255,${0.12 + (i % 5) * 0.05})`;
    ctx.fillRect(x, y, 2, 2);
  }
  ctx.restore();
}

function drawGround(ctx, t) {
  ctx.save();
  ctx.globalAlpha = 0.75;
  ctx.fillStyle = "#2a1420";
  ctx.beginPath();
  ctx.moveTo(0, GAME.BASE_HEIGHT);
  for (let x = 0; x <= GAME.BASE_WIDTH; x += 24) {
    const y = GAME.BASE_HEIGHT - 60 - Math.sin((x + t * 45) * 0.02) * 18;
    ctx.lineTo(x, y);
  }
  ctx.lineTo(GAME.BASE_WIDTH, GAME.BASE_HEIGHT);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  ctx.save();
  ctx.globalAlpha = 0.12;
  ctx.fillStyle = "#fbbf24";
  ctx.fillRect(0, GAME.BASE_HEIGHT - 110, GAME.BASE_WIDTH, 110);
  ctx.restore();
}

function drawCactus(ctx, x, y, w, h, isTop) {
  ctx.save();
  ctx.fillStyle = "#1c7c54";
  ctx.fillRect(x, y, w, h);

  ctx.fillStyle = "rgba(0,0,0,0.20)";
  for (let i = 1; i < 5; i++) {
    const rx = x + (w * i) / 6;
    ctx.fillRect(rx, y, 3, h);
  }

  ctx.fillStyle = "rgba(255,255,255,0.10)";
  for (let yy = y + 8; yy < y + h; yy += 18) {
    ctx.fillRect(x + 6, yy, w - 12, 1);
  }

  ctx.fillStyle = "rgba(255,255,255,0.12)";
  if (isTop) ctx.fillRect(x, y + h - 6, w, 6);
  else ctx.fillRect(x, y, w, 6);

  ctx.restore();
}

function drawOwl(ctx, x, y, rot, blink) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);

  ctx.fillStyle = "#e5e7eb";
  roundRect(ctx, -OWL.WIDTH / 2, -OWL.HEIGHT / 2, OWL.WIDTH, OWL.HEIGHT, 12);
  ctx.fill();

  ctx.fillStyle = "rgba(0,0,0,0.12)";
  roundRect(ctx, -10, -2, 22, 14, 10);
  ctx.fill();

  ctx.fillStyle = "#111827";
  if (!blink) {
    ctx.beginPath(); ctx.arc(6, -6, 3.2, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(-6, -6, 3.2, 0, Math.PI * 2); ctx.fill();
  } else {
    ctx.fillRect(-10, -7, 8, 2);
    ctx.fillRect(2, -7, 8, 2);
  }

  ctx.fillStyle = "#fbbf24";
  ctx.beginPath();
  ctx.moveTo(0, -1);
  ctx.lineTo(6, 6);
  ctx.lineTo(-6, 6);
  ctx.closePath();
  ctx.fill();

  ctx.restore();
}

function roundRect(ctx, x, y, w, h, r) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}
