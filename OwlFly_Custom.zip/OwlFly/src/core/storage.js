import { STORAGE_KEYS } from "./constants.js";

export function loadHighScore() {
  const raw = localStorage.getItem(STORAGE_KEYS.HIGH_SCORE);
  const n = raw ? Number(raw) : 0;
  return Number.isFinite(n) && n >= 0 ? Math.floor(n) : 0;
}

export function saveHighScore(score) {
  const n = Math.max(0, Math.floor(score));
  localStorage.setItem(STORAGE_KEYS.HIGH_SCORE, String(n));
}

export function loadSettings() {
  const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
  if (!raw) return { muted: false, reducedMotion: false };
  try {
    const obj = JSON.parse(raw);
    return {
      muted: !!obj.muted,
      reducedMotion: !!obj.reducedMotion
    };
  } catch {
    return { muted: false, reducedMotion: false };
  }
}

export function saveSettings(settings) {
  const safe = {
    muted: !!settings?.muted,
    reducedMotion: !!settings?.reducedMotion
  };
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(safe));
}
