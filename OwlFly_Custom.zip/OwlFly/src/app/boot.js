import { GAME, OWL } from "../core/constants.js";
import { RNG } from "../core/rng.js";
import { loadSettings, saveSettings } from "../core/storage.js";
import { circleAabbIntersect } from "../engine/collision.js";
import { Input } from "../engine/input.js";
import { GameLoop } from "../engine/gameLoop.js";
import { Difficulty } from "../engine/difficulty.js";
import { Owl } from "../engine/entities/owl.js";
import { Spawner } from "../systems/spawner.js";
import { Scoring } from "../systems/scoring.js";
import { Renderer } from "../render/renderer.js";
import { MenuUI } from "../ui/menu.js";
import { HudUI } from "../ui/hud.js";
import { GameOverUI } from "../ui/gameOver.js";

const canvas = document.getElementById("game");
if (!canvas) throw new Error("Missing canvas#game");

const menuEl = document.getElementById("menu");
const hudEl = document.getElementById("hud");
const gameOverEl = document.getElementById("gameover");
if (!menuEl || !hudEl || !gameOverEl) throw new Error("Missing UI root elements");

const renderer = new Renderer(canvas);
const input = new Input(canvas);

const rng = new RNG();
const difficulty = new Difficulty();
const owl = new Owl();
const scoring = new Scoring();
const spawner = new Spawner(rng, difficulty);

const audio = makeAudio({
  jump: "./assets/audio/jump.mp3",
  score: "./assets/audio/score.mp3",
  hit: "./assets/audio/hit.mp3"
});

let settings = loadSettings();
audio.setMuted(settings.muted);

const uiMenu = new MenuUI(menuEl);
const uiHud = new HudUI(hudEl);
const uiOver = new GameOverUI(gameOverEl);

const state = {
  mode: "menu",
  paused: false,
  owl,
  spawner,
  scoring,
  difficulty,
  settings
};

function hardResetRun() {
  difficulty.reset();
  owl.reset();
  spawner.reset();
  state.paused = false;
}

function startGame() {
  hardResetRun();
  scoring.reset(); // keeps best via localStorage
  state.mode = "playing";
  uiMenu.hide();
  uiOver.hide();
  uiHud.show();
  uiHud.setScore(0);
}

function toMenu() {
  state.mode = "menu";
  state.paused = false;
  uiHud.hide();
  uiOver.hide();
  uiMenu.show({
    best: scoring.best,
    muted: settings.muted,
    reducedMotion: settings.reducedMotion,
    onStart: () => startGame(),
    onToggleMute: () => toggleMute(),
    onToggleRM: () => toggleReducedMotion()
  });
}

function gameOver() {
  state.mode = "gameover";
  uiHud.hide();
  uiOver.show({
    score: scoring.score,
    best: scoring.best,
    onRestart: () => startGame(),
    onMenu: () => toMenu()
  });
}

function toggleMute() {
  settings.muted = !settings.muted;
  saveSettings(settings);
  audio.setMuted(settings.muted);
  if (state.mode === "menu") toMenu();
}

function toggleReducedMotion() {
  settings.reducedMotion = !settings.reducedMotion;
  saveSettings(settings);
  if (state.mode === "menu") toMenu();
}

function step(dt) {
  if (input.consumePause() && state.mode === "playing") {
    state.paused = !state.paused;
    loop.setPaused(state.paused);
  }

  if (state.mode !== "playing") {
    if (state.mode === "menu" && input.consumeJump()) startGame();
    if (state.mode === "gameover" && input.consumeJump()) startGame();
    return;
  }

  if (state.paused) return;

  if (input.consumeJump()) {
    owl.flap();
    audio.play("jump");
  }

  difficulty.update(dt);
  owl.update(dt);
  spawner.update(dt);

  if (owl.y < 0 + OWL.HEIGHT / 2 || owl.y > GAME.BASE_HEIGHT - OWL.HEIGHT / 2) {
    crash();
    return;
  }

  const c = owl.getCircle();
  for (const o of spawner.active) {
    if (!o.active) continue;
    const { top, bottom } = o.getRects();

    if (circleAabbIntersect(c.cx, c.cy, c.r, top) || circleAabbIntersect(c.cx, c.cy, c.r, bottom)) {
      crash();
      return;
    }

    if (!o.passed && o.x + top.w < owl.x - OWL.WIDTH / 2) {
      o.passed = true;
      scoring.onPassObstacle();
      uiHud.setScore(scoring.score);
      audio.play("score");
    }
  }
}

function crash() {
  owl.kill();
  scoring.onCrash();
  audio.play("hit");

  loop.setPaused(false);
  setTimeout(() => {
    if (state.mode === "playing") {
      state.mode = "gameover";
      gameOver();
    }
  }, 260);
}

function render() {
  renderer.render(state);
}

const loop = new GameLoop(step, render);
loop.start();

toMenu();

function makeAudio(map) {
  const nodes = {};
  for (const [k, url] of Object.entries(map)) {
    const a = new Audio(url);
    a.preload = "auto";
    nodes[k] = a;
  }

  let muted = false;

  return {
    setMuted(v) { muted = !!v; },
    play(key) {
      if (muted) return;
      const a = nodes[key];
      if (!a) return;
      try {
        a.currentTime = 0;
        a.play().catch(() => {});
      } catch {}
    }
  };
}
