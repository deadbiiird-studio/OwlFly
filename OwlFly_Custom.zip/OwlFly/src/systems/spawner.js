import { CACTUS, GAME, SPAWN } from "../core/constants.js";
import { CactusPair } from "../engine/entities/cactusPair.js";

export class Spawner {
  constructor(rng, difficulty) {
    this.rng = rng;
    this.difficulty = difficulty;

    this.pool = [];
    this.active = [];

    this._spawnTimer = 0;
    this._spawnCount = 0;

    this._easyRemaining = 0;

    for (let i = 0; i < 8; i++) this.pool.push(new CactusPair());
  }

  reset() {
    for (const o of this.active) o.despawn();
    this.active.length = 0;
    this._spawnTimer = 0;
    this._spawnCount = 0;
    this._easyRemaining = 0;
  }

  update(dt) {
    this._spawnTimer += dt;

    for (const o of this.active) o.update(dt);

    for (let i = this.active.length - 1; i >= 0; i--) {
      const o = this.active[i];
      if (!o.active) {
        this.active.splice(i, 1);
        this.pool.push(o);
      }
    }

    const interval = this.difficulty.spawnInterval;

    if (this._spawnTimer >= interval) {
      this._spawnTimer -= interval;
      this.spawnOne();
    }
  }

  spawnOne() {
    this._spawnCount++;
    if (this._spawnCount % SPAWN.EASY_INJECTION_EVERY === 0) {
      this._easyRemaining = SPAWN.EASY_INJECTION_COUNT;
    }

    const isEasy = this._easyRemaining > 0;
    if (isEasy) this._easyRemaining--;

    const gapBase = this.difficulty.gap;
    const gap = clamp(
      gapBase + (isEasy ? SPAWN.EASY_GAP_BONUS : 0),
      CACTUS.MIN_GAP,
      CACTUS.MAX_GAP + SPAWN.EASY_GAP_BONUS
    );

    const speed = clamp(
      this.difficulty.speed - (isEasy ? SPAWN.EASY_SPEED_PENALTY : 0),
      160,
      CACTUS.SPEED_MAX
    );

    const maxTop = GAME.BASE_HEIGHT - CACTUS.MIN_BOTTOM - gap;
    const minTop = CACTUS.MIN_TOP;
    const topH = Math.floor(this.rng.range(minTop, Math.max(minTop + 1, maxTop)));

    const o = this.pool.length ? this.pool.pop() : new CactusPair();
    o.spawn({
      x: GAME.BASE_WIDTH + 40,
      topH,
      gap,
      speed
    });
    this.active.push(o);
  }
}

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}
