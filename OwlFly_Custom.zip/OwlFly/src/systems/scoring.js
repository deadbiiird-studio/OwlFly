import { loadHighScore, saveHighScore } from "../core/storage.js";

export class Scoring {
  constructor() {
    this.reset();
  }

  reset() {
    this.score = 0;
    this.best = loadHighScore();
    this.combo = 0;
    this.runs = 0;
  }

  onPassObstacle() {
    this.score += 1;
    this.combo += 1;
    if (this.score > this.best) {
      this.best = this.score;
      saveHighScore(this.best);
    }
  }

  onCrash() {
    this.combo = 0;
    this.runs += 1;
  }
}
