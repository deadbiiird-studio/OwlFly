import { CACTUS, DIFFICULTY, SPAWN } from "../core/constants.js";

export class Difficulty {
  constructor() {
    this.time = 0;
    this.speed = CACTUS.BASE_SPEED;
    this.gap = (CACTUS.MIN_GAP + CACTUS.MAX_GAP) / 2;
    this.spawnInterval = SPAWN.BASE_INTERVAL;
  }

  reset() {
    this.time = 0;
    this.speed = CACTUS.BASE_SPEED;
    this.gap = (CACTUS.MIN_GAP + CACTUS.MAX_GAP) / 2;
    this.spawnInterval = SPAWN.BASE_INTERVAL;
  }

  update(dt) {
    this.time += dt;

    this.speed = Math.min(
      CACTUS.SPEED_MAX,
      this.speed + DIFFICULTY.SPEED_RAMP_PER_SEC * dt
    );

    this.gap = Math.max(
      CACTUS.MIN_GAP,
      this.gap - DIFFICULTY.GAP_SHRINK_PER_SEC * dt
    );

    this.spawnInterval = Math.max(
      SPAWN.MIN_INTERVAL,
      this.spawnInterval - DIFFICULTY.INTERVAL_SHRINK_PER_SEC * dt
    );
  }
}
