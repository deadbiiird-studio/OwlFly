import { OWL, GAME } from "../../core/constants.js";
import { applyGravity, jumpImpulse, rotationForVelocity } from "../physics.js";

export class Owl {
  constructor() {
    this.reset();
  }

  reset() {
    this.x = OWL.X;
    this.y = GAME.BASE_HEIGHT * 0.45;
    this.vy = 0;
    this.rot = 0;
    this.alive = true;
    this._blink = 0;
  }

  flap() {
    if (!this.alive) return;
    this.vy = jumpImpulse();
    this._blink = 0.08;
  }

  kill() {
    this.alive = false;
  }

  update(dt) {
    if (this.alive) {
      this.vy = applyGravity(this.vy, dt);
      this.y += this.vy * dt;
      this.rot = rotationForVelocity(this.vy);
      this._blink = Math.max(0, this._blink - dt);
    } else {
      this.vy = applyGravity(this.vy, dt);
      this.y += this.vy * dt;
      this.rot = Math.min(1.6, this.rot + dt * 2.2);
    }
  }

  getAabb() {
    return {
      x: this.x - OWL.WIDTH / 2,
      y: this.y - OWL.HEIGHT / 2,
      w: OWL.WIDTH,
      h: OWL.HEIGHT
    };
  }

  getCircle() {
    return { cx: this.x, cy: this.y, r: OWL.RADIUS };
  }

  get blink() {
    return this._blink > 0;
  }
}
