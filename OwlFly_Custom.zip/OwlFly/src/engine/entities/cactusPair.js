import { CACTUS, GAME } from "../../core/constants.js";

export class CactusPair {
  constructor() {
    this.active = false;
    this.passed = false;
    this.x = GAME.BASE_WIDTH + 200;
    this.topH = 200;
    this.gap = 200;
    this.speed = CACTUS.BASE_SPEED;
  }

  spawn({ x, topH, gap, speed }) {
    this.active = true;
    this.passed = false;
    this.x = x;
    this.topH = topH;
    this.gap = gap;
    this.speed = speed;
  }

  despawn() {
    this.active = false;
  }

  update(dt) {
    if (!this.active) return;
    this.x -= this.speed * dt;
    if (this.x + CACTUS.WIDTH < -40) this.despawn();
  }

  getRects() {
    const top = { x: this.x, y: 0, w: CACTUS.WIDTH, h: this.topH };
    const bottomY = this.topH + this.gap;
    const bottom = { x: this.x, y: bottomY, w: CACTUS.WIDTH, h: GAME.BASE_HEIGHT - bottomY };
    return { top, bottom };
  }

  getGapCenterY() {
    return this.topH + this.gap / 2;
  }
}
