import { WORLD } from "../core/constants.js";

export function applyGravity(vy, dt) {
  vy += WORLD.GRAVITY * dt;
  if (vy > WORLD.MAX_FALL_SPEED) vy = WORLD.MAX_FALL_SPEED;
  return vy;
}

export function jumpImpulse() {
  return -WORLD.JUMP_IMPULSE;
}

export function rotationForVelocity(vy) {
  const t = Math.max(-1, Math.min(1, vy / WORLD.MAX_FALL_SPEED));
  if (t < 0) return WORLD.ROT_UP * Math.min(1, -t * 2.2);
  return WORLD.ROT_DOWN * Math.min(1, t * 1.1);
}
