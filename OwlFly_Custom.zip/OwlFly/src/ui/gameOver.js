export class GameOverUI {
  constructor(rootEl) {
    this.el = rootEl;
  }

  show({ score, best, onRestart, onMenu }) {
    this.el.classList.remove("hidden");
    this.el.innerHTML = `
      <h2>Game Over</h2>
      <p>Score: <strong>${score}</strong> • Best: <strong>${best}</strong></p>
      <div class="row">
        <button class="primary" id="restartBtn">Restart</button>
        <button id="menuBtn">Menu</button>
      </div>
      <p><small>Tip: The game injects a few easier cactus gates sometimes to help you build confidence.</small></p>
    `;
    this.el.querySelector("#restartBtn")?.addEventListener("click", onRestart);
    this.el.querySelector("#menuBtn")?.addEventListener("click", onMenu);
  }

  hide() {
    this.el.classList.add("hidden");
    this.el.innerHTML = "";
  }
}
