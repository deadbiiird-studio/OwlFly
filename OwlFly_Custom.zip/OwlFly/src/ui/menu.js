export class MenuUI {
  constructor(rootEl) {
    this.el = rootEl;
    this.el.innerHTML = "";
  }

  show({ best, muted, reducedMotion, onStart, onToggleMute, onToggleRM }) {
    this.el.classList.remove("hidden");
    this.el.innerHTML = `
      <h1>OwlFly</h1>
      <p>Tap to fly. Dodge cactus gates. Beat your best.</p>
      <p><small>Best: <strong>${best}</strong></small></p>
      <div class="row">
        <button class="primary" id="startBtn">Start</button>
        <button id="muteBtn">${muted ? "Unmute" : "Mute"}</button>
        <button id="rmBtn">${reducedMotion ? "Motion: Low" : "Motion: Full"}</button>
      </div>
      <p><small>Controls: Tap/Click/Space • Esc pause • Enter restart</small></p>
    `;

    this.el.querySelector("#startBtn")?.addEventListener("click", onStart);
    this.el.querySelector("#muteBtn")?.addEventListener("click", onToggleMute);
    this.el.querySelector("#rmBtn")?.addEventListener("click", onToggleRM);
  }

  hide() {
    this.el.classList.add("hidden");
  }
}
