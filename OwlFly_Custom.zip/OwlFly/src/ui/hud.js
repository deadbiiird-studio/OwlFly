export class HudUI {
  constructor(rootEl) {
    this.el = rootEl;
  }

  show() {
    this.el.classList.remove("hidden");
    this.el.innerHTML = `<div class="pill" id="scorePill">0</div>`;
    this._pill = this.el.querySelector("#scorePill");
  }

  setScore(score) {
    if (this._pill) this._pill.textContent = String(score);
  }

  hide() {
    this.el.classList.add("hidden");
    this.el.innerHTML = "";
    this._pill = null;
  }
}
